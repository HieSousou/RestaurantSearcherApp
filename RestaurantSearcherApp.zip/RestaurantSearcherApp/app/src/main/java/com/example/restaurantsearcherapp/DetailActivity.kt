package com.example.restaurantsearcherapp

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.squareup.picasso.Picasso

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.details)  // レイアウトファイルをセット

        // ビューをレイアウトから取得
        val DStorName: TextView = findViewById(R.id.DStorName)
        val DAddress: TextView = findViewById(R.id.DAddress)
        val DStationName: TextView = findViewById(R.id.DStationName)
        val DAccess: TextView = findViewById(R.id.DAccess)
        val DTime: TextView = findViewById(R.id.DTime)
        val DClose: TextView = findViewById(R.id.DClose)
        val DAverage: TextView = findViewById(R.id.DAverage)
        val DEquipment: TextView = findViewById(R.id.DEquipment)
        val DivStor: ImageView = findViewById(R.id.DivStor)
        val btBack: Button = findViewById(R.id.btBack)  // 戻るボタン

        // コンテナのビューを取得
        val clDAddress: View = findViewById(R.id.clDAddress)
        val clDTime: View = findViewById(R.id.clDTime)
        val clDStationName: View = findViewById(R.id.clDStationName)
        val clDAverage: View = findViewById(R.id.clDAverage)
        val clDAccess: View = findViewById(R.id.clDAccess)
        val clDClose: View = findViewById(R.id.clDClose)


        // インテントからデータを取得
        val name = intent.getStringExtra("name") ?: ""
        val address = intent.getStringExtra("address") ?: ""
        val open = intent.getStringExtra("open") ?: ""
        val image = intent.getStringExtra("image") ?: ""
        val stationName = intent.getStringExtra("station_name") ?: ""
        val average = intent.getStringExtra("average") ?: ""
        val access = intent.getStringExtra("access") ?: ""
        val close = intent.getStringExtra("close") ?: ""

        val details = mapOf(
            "最大宴会収容人数" to intent.getStringExtra("party_capacity"),
            "WiFi 有無" to intent.getStringExtra("wifi"),
            "ウェディング･二次会" to intent.getStringExtra("wedding"),
            "コース" to intent.getStringExtra("course"),
            "飲み放題" to intent.getStringExtra("free_drink"),
            "食べ放題" to intent.getStringExtra("free_food"),
            "個室" to intent.getStringExtra("private_room"),
            "掘りごたつ" to intent.getStringExtra("horigotatsu"),
            "座敷" to intent.getStringExtra("tatami"),
            "カード可" to intent.getStringExtra("card"),
            "禁煙席" to intent.getStringExtra("non_smoking"),
            "貸切可" to intent.getStringExtra("charter"),
            "携帯電話OK" to intent.getStringExtra("ktai"),
            "駐車場" to intent.getStringExtra("parking"),
            "バリアフリー" to intent.getStringExtra("barrier_free"),
            "その他設備" to intent.getStringExtra("other_memo"),
            "ソムリエ" to intent.getStringExtra("sommelier"),
            "オープンエア" to intent.getStringExtra("open_air"),
            "ライブ・ショー" to intent.getStringExtra("show"),
            "エンタメ設備" to intent.getStringExtra("equipment"),
            "カラオケ" to intent.getStringExtra("karaoke"),
            "バンド演奏可" to intent.getStringExtra("band"),
            "TV・プロジェクター" to intent.getStringExtra("tv"),
            "英語メニュー" to intent.getStringExtra("english"),
            "ペット可" to intent.getStringExtra("pet"),
            "お子様連れ" to intent.getStringExtra("child"),
            "ランチ" to intent.getStringExtra("lunch"),
            "23時以降も営業" to intent.getStringExtra("midnight")
        ).filterNot { it.value.isNullOrEmpty() || it.value == "なし" }
            .map { "${it.key}: ${it.value}" }
            .joinToString("\n")

        // データをビューに設定、空の場合はビューを非表示にする
        if (!name.isNullOrEmpty()) DStorName.text = name else DStorName.visibility = View.GONE
        if (!address.isNullOrEmpty()) DAddress.text = address else clDAddress.visibility = View.GONE
        if (!open.isNullOrEmpty()) DTime.text = open else clDTime.visibility = View.GONE
        if (!stationName.isNullOrEmpty()) DStationName.text = stationName else clDStationName.visibility = View.GONE
        if (!average.isNullOrEmpty()) DAverage.text = average else clDAverage.visibility = View.GONE
        if (!access.isNullOrEmpty()) DAccess.text = access else clDAccess.visibility = View.GONE
        if (!close.isNullOrEmpty()) DClose.text = close else clDClose.visibility = View.GONE
        DEquipment.text = details

        Picasso.get().load(image).into(DivStor)

        // 戻るボタンのクリックリスナーを設定
        btBack.setOnClickListener {
            finish()  // 現在のアクティビティを終了し、前のアクティビティに戻る
        }
    }
}
