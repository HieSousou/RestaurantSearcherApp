package com.example.restaurantsearcherapp

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

interface HotPepperApi {
    @GET("gourmet/v1/")
    fun searchRestaurants(
        @Query("key") apiKey: String,
        @Query("lat") latitude: Double,
        @Query("lng") longitude: Double,
        @Query("range") range: Int,
        @Query("count") count: Int,       // 1ページあたりの取得数
        @Query("start") start: Int,
//        @Query("genre") genre: String,
//        @Query("private_room") privateRoom: Boolean,
//        @Query("horigotatsu") horigotatsu: Boolean,
//        @Query("tatami") tatami: Boolean,
//        @Query("non_smoking") nonSmoking: Boolean,
//        @Query("free_drink") freeDrink: Boolean,
//        @Query("free_food") freeFood: Boolean,
//        @Query("lunch") lunch: Boolean,
//        @Query("course") course: Boolean,
//        @Query("card") card: Boolean,
//        @Query("barrier_free") barrierFree: Boolean,
//        @Query("pet") pet: Boolean,
//        @Query("charter") charter: Boolean,
//        @Query("tv") tv: Boolean,
//        @Query("wifi") wifi: Boolean,
//        @Query("midnight_meal") midnightMeal: Boolean,
//        @Query("child") child: Boolean,
//        @Query("midnight") midnight: Boolean,
//        @Query("parking") parking: Boolean,
//        @Query("english") english: Boolean,
//        @Query("wedding") wedding: Boolean,
//        @Query("mobile_phone") ktai: Boolean,
//        @Query("sake") sake: Boolean,
//        @Query("wine") wine: Boolean,
//        @Query("sommelier") sommelier: Boolean,
//        @Query("shochu") shochu: Boolean,
//        @Query("cocktail") cocktail: Boolean,
//        @Query("night_view") nightView: Boolean,
//        @Query("open_air") openAir: Boolean,
//        @Query("show") show: Boolean,
//        @Query("karaoke") karaoke: Boolean,
//        @Query("entertainment_equipment") entertainmentEquipment: Boolean,
//        @Query("band") band: Boolean,
        @Query("format") format: String = "json"
    ): Call<RestaurantResponse>
}
