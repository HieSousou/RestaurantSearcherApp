package com.example.restaurantsearcherapp

import android.Manifest
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.math.RoundingMode

class MainActivity : AppCompatActivity(), ListAdapter.OnRestaurantClickListener {
    private lateinit var spScope: Spinner // 検索範囲を選択するスピナー
    private lateinit var tvPageView: TextView // ページ番号を表示するテキストビュー
    private lateinit var btSearch: Button // 検索ボタン
    private lateinit var btPrev: Button // 前のページへボタン
    private lateinit var btNext: Button // 次のページへボタン
    private lateinit var recyclerView: RecyclerView // レストランのリストを表示するためのリサイクラービュー
    private lateinit var recyclerAdapter: ListAdapter // リサイクラービューのアダプタ
    private lateinit var fusedLocationClient: FusedLocationProviderClient // 位置情報を取得するクライアント
    private lateinit var btterm: Button // 条件を指定するためのボタン
    private var currentPage = 1 // 現在のページ番号
    private var currentStor = 1 //現在の店舗番号
    private var totalPage = 1 // 総ページ数

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 各ウィジェットをレイアウトから取得
        btPrev = findViewById(R.id.btPrev)
        btNext = findViewById(R.id.btNext)
        tvPageView = findViewById(R.id.tvPageView)
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        spScope = findViewById(R.id.spScope)
        btSearch = findViewById(R.id.btSearch)
        btterm = findViewById(R.id.btterm)
        recyclerView = findViewById(R.id.recyclerView)
        recyclerAdapter = ListAdapter(ArrayList(), this)
        recyclerView.adapter = recyclerAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 最初は前のページへのボタンを無効にする
        btPrev.isEnabled = false // Initially disable the 'Previous' button

        // 次のページへのボタンのリスナーを設定
        btNext.setOnClickListener {
            currentStor =currentStor+10
            currentPage++
            updateListForPage(currentStor)
        }

        // 前のページへのボタンのリスナーを設定
        btPrev.setOnClickListener {
            if (currentStor > 1) {
                currentStor = currentStor-10
                currentPage--
                updateListForPage(currentStor)
            }
        }

        // 検索ボタンのリスナーを設定
        btSearch.setOnClickListener {
            currentStor = 1 // Reset to the first page
            updateListForPage(currentStor)
        }

        // スピナーにアダプターを設定（検索範囲選択用）
        ArrayAdapter.createFromResource(
            this,
            R.array.range_options,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spScope.adapter = adapter
        }

        // 条件指定ボタンのリスナーを設定
        btterm.setOnClickListener {
            val dialogView = layoutInflater.inflate(R.layout.terms, null)  // ダイアログに表示するレイアウト
            //ジャンル絞り込み
            val spGenre = dialogView.findViewById<Spinner>(R.id.spGenre)

            //予算絞り込み
            val sbBudget = dialogView.findViewById<SeekBar>(R.id.sbBudget)

            //席絞り込み
            val btSeat = dialogView.findViewById<Button>(R.id.btSeat)
            val clSeat = dialogView.findViewById<View>(R.id.clSeat)
            val swPrivateRoom = dialogView.findViewById<Switch>(R.id.swPrivateRoom)
            val swHorigotatsu = dialogView.findViewById<Switch>(R.id.swHorigotatsu)
            val swTatami = dialogView.findViewById<Switch>(R.id.swTatami)
            val swNonSmoking = dialogView.findViewById<Switch>(R.id.swNonSmoking)

            //食事絞り込み
            val btMeal = dialogView.findViewById<Button>(R.id.btMeal)
            val clMeal = dialogView.findViewById<View>(R.id.clMeal)
            val swFreeDrink = dialogView.findViewById<Switch>(R.id.swFreeDrink)
            val swFreeFood = dialogView.findViewById<Switch>(R.id.swFreeFood)
            val swLunch = dialogView.findViewById<Switch>(R.id.swLunch)
            val swCourse = dialogView.findViewById<Switch>(R.id.swCourse)

            //支払い絞り込み
            val btPayment = dialogView.findViewById<Button>(R.id.btPayment)
            val clPayment = dialogView.findViewById<View>(R.id.clPayment)
            val swCard = dialogView.findViewById<Switch>(R.id.swCard)

            //設備絞り込み
            val btEquipment = dialogView.findViewById<Button>(R.id.btEquipment)
            val clEquipment = dialogView.findViewById<View>(R.id.clEquipment)
            val swBarrierFree = dialogView.findViewById<Switch>(R.id.swBarrierFree)
            val swPet = dialogView.findViewById<Switch>(R.id.swPet)
            val swCharter = dialogView.findViewById<Switch>(R.id.swCharter)
            val swTv = dialogView.findViewById<Switch>(R.id.swTv)
            val swWifi = dialogView.findViewById<Switch>(R.id.swWifi)
            val swMidnightMeal = dialogView.findViewById<Switch>(R.id.swMidnightMeal)
            val swChild = dialogView.findViewById<Switch>(R.id.swChild)
            val swMidnight = dialogView.findViewById<Switch>(R.id.swMidnight)
            val swParking = dialogView.findViewById<Switch>(R.id.swParking)
            val swEnglish = dialogView.findViewById<Switch>(R.id.swEnglish)
            val swwWedding = dialogView.findViewById<Switch>(R.id.swwWedding)
            val swKtai = dialogView.findViewById<Switch>(R.id.swKtai)

            //お酒絞り込み
            val btAlcohol = dialogView.findViewById<Button>(R.id.btAlcohol)
            val clAlcohol = dialogView.findViewById<View>(R.id.clAlcohol)
            val swSake = dialogView.findViewById<Switch>(R.id.swSake)
            val swWine = dialogView.findViewById<Switch>(R.id.swWine)
            val swSommelier = dialogView.findViewById<Switch>(R.id.swSommelier)
            val swShochu = dialogView.findViewById<Switch>(R.id.swShochu)
            val swCocktail = dialogView.findViewById<Switch>(R.id.swCocktail)

            //場所絞り込み
            val btLocation = dialogView.findViewById<Button>(R.id.btLocation)
            val clLocation = dialogView.findViewById<View>(R.id.clLocation)
            val swNightView = dialogView.findViewById<Switch>(R.id.swNightView)
            val swOpenAir = dialogView.findViewById<Switch>(R.id.swOpenAir)

            //エンタメ系絞り込み
            val btEntertainment = dialogView.findViewById<Button>(R.id.btEntertainment)
            val clEntertainment = dialogView.findViewById<View>(R.id.clEntertainment)
            val swShow = dialogView.findViewById<Switch>(R.id.swShow)
            val swKaraoke = dialogView.findViewById<Switch>(R.id.swKaraoke)
            val swEquipment = dialogView.findViewById<Switch>(R.id.swEquipment)
            val swBand = dialogView.findViewById<Switch>(R.id.swBand)

            btSeat.setOnClickListener {
                // clMealの可視性を切り替える
                clSeat.visibility = if (clSeat.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btMeal.setOnClickListener {
                // clMealの可視性を切り替える
                clMeal.visibility = if (clMeal.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btPayment.setOnClickListener {
                // clMealの可視性を切り替える
                clPayment.visibility = if (clPayment.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btEquipment.setOnClickListener {
                // clMealの可視性を切り替える
                clEquipment.visibility = if (clEquipment.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btAlcohol.setOnClickListener {
                // clMealの可視性を切り替える
                clAlcohol.visibility = if (clAlcohol.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btLocation.setOnClickListener {
                // clMealの可視性を切り替える
                clLocation.visibility = if (clLocation.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            btEntertainment.setOnClickListener {
                // clMealの可視性を切り替える
                clEntertainment.visibility = if (clEntertainment.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            AlertDialog.Builder(this)
                .setTitle("条件を絞り込んでください")
                .setView(dialogView)
                .setPositiveButton("絞り込み") { dialogInterface, i ->
                    val budget = sbBudget.progress
                    val privateRoom = swPrivateRoom.isChecked
                    val horigotatsu = swHorigotatsu.isChecked
                    val tatami = swTatami.isChecked
                    val nonSmoking = swNonSmoking.isChecked
                    val freeDrink = swFreeDrink.isChecked
                    val freeFood = swFreeFood.isChecked
                    val lunch = swLunch.isChecked
                    val course = swCourse.isChecked
                    val cardPayment = swCard.isChecked
                    val barrierFree = swBarrierFree.isChecked
                    val petFriendly = swPet.isChecked
                    val charter = swCharter.isChecked
                    val tv = swTv.isChecked
                    val wifi = swWifi.isChecked
                    val midnightMeal = swMidnightMeal.isChecked
                    val childFriendly = swChild.isChecked
                    val operatesMidnight = swMidnight.isChecked
                    val parkingAvailable = swParking.isChecked
                    val englishSpeaking = swEnglish.isChecked
                    val weddingSupport = swwWedding.isChecked
                    val mobilePhone = swKtai.isChecked
                    val sake = swSake.isChecked
                    val wine = swWine.isChecked
                    val sommelier = swSommelier.isChecked
                    val shochu = swShochu.isChecked
                    val cocktail = swCocktail.isChecked
                    val nightView = swNightView.isChecked
                    val openAir = swOpenAir.isChecked
                    val show = swShow.isChecked
                    val karaoke = swKaraoke.isChecked
                    val entertainmentEquipment = swEquipment.isChecked
                    val band = swBand.isChecked
//                    getLocationAndSearch(privateRoom, horigotatsu, tatami, nonSmoking,
//                        freeDrink, freeFood, lunch, course, cardPayment, barrierFree, petFriendly, charter,
//                        tv, wifi, midnightMeal, childFriendly, operatesMidnight, parkingAvailable, englishSpeaking,
//                        weddingSupport, mobilePhone, sake, wine, sommelier, shochu, cocktail, nightView, openAir,
//                        show, karaoke, entertainmentEquipment, band)

                }
                .setNegativeButton("戻る", null)
                .show()
        }


    }

    private fun updateListForPage(page: Int) {
        val selectedRange = spScope.selectedItem.toString()
        val range = when (selectedRange) {
            "300m以内" -> 1
            "500m以内" -> 2
            "1km以内" -> 3
            "2km以内" -> 4
            "3km以内" -> 5
            else -> 3

        }

        getLocationAndSearch(range, page, 10)// 指定した範囲でレストランを検索
    }

    private fun getLocationAndSearch(range: Int, page: Int = 1, count: Int = 100) {
        // 位置情報の権限確認
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            return
        }

        // 位置情報が取得できたらレストランを検索
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                ApiClient.instance.searchRestaurants("cece05cc354db6c4", location.latitude, location.longitude, range, count, page).enqueue(object : Callback<RestaurantResponse> {
                    override fun onResponse(call: Call<RestaurantResponse>, response: Response<RestaurantResponse>) {
                        if (response.isSuccessful) {
                            response.body()?.let { body ->
                                val shops = body.results.shop
                                val totalRecords = body.results.results_available // APIからの総件数を取得
                                val itemsPerPage = 10 // 一ページあたりのアイテム数
                                val totalPage = (totalRecords + itemsPerPage - 1) / itemsPerPage // 全ページ数を計算
                                recyclerAdapter.updateData(shops)
                                runOnUiThread {
                                    tvPageView.text = "検索結果: $totalRecords 件 (${currentPage}/${totalPage})" // 総件数とページ情報をテキストビューに表示
                                    btPrev.isEnabled = page > 1
                                    btNext.isEnabled = shops.size == count
                                }
                            }
                        }
                    }

                    override fun onFailure(call: Call<RestaurantResponse>, t: Throwable) {
                        // Handle failure
                    }
                })
            }
        }
    }

    override fun onRestaurantClick(restaurant: Restaurant) {
        val intent = Intent(this, DetailActivity::class.java).apply {
            // レストランの詳細情報をインテントにセットして詳細画面へ遷移
            putExtra("name", restaurant.name)
            putExtra("address", restaurant.address)
            putExtra("image", restaurant.logo_image)
            putExtra("station_name", restaurant.station_name)
            putExtra("average", restaurant.average)
            putExtra("access", restaurant.access)
            putExtra("open", restaurant.open)
            putExtra("close", restaurant.close)
            putExtra("party_capacity", restaurant.party_capacity)
            putExtra("wifi", restaurant.wifi)
            putExtra("wedding", restaurant.wedding)
            putExtra("course", restaurant.course)
            putExtra("free_drink", restaurant.free_drink)
            putExtra("free_food", restaurant.free_food)
            putExtra("private_room", restaurant.private_room)
            putExtra("horigotatsu", restaurant.horigotatsu)
            putExtra("tatami", restaurant.tatami)
            putExtra("card", restaurant.card)
            putExtra("non_smoking", restaurant.non_smoking)
            putExtra("charter", restaurant.charter)
            putExtra("ktai", restaurant.ktai)
            putExtra("parking", restaurant.parking)
            putExtra("barrier_free", restaurant.barrier_free)
            putExtra("other_memo", restaurant.other_memo)
            putExtra("sommelier", restaurant.sommelier)
            putExtra("open_air", restaurant.open_air)
            putExtra("show", restaurant.show)
            putExtra("equipment", restaurant.equipment)
            putExtra("karaoke", restaurant.karaoke)
            putExtra("band", restaurant.band)
            putExtra("tv", restaurant.tv)
            putExtra("english", restaurant.english)
            putExtra("pet", restaurant.pet)
            putExtra("child", restaurant.child)
            putExtra("lunch", restaurant.lunch)
            putExtra("midnight", restaurant.midnight)


        }
        startActivity(intent)// 詳細画面へ遷移
    }

}