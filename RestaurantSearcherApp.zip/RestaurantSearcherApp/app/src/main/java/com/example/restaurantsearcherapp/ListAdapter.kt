package com.example.restaurantsearcherapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class ListAdapter(
    private val restaurantList: ArrayList<Restaurant>, // レストラン情報のリスト
    private val listener: OnRestaurantClickListener // クリックイベントを処理するためのリスナー
) : RecyclerView.Adapter<ListAdapter.ViewHolderItem>() {

    // OnRestaurantClickListenerインターフェイスを定義して、レストランがクリックされたときの処理を外部から設定できるようにしています。
    interface OnRestaurantClickListener {
        fun onRestaurantClick(restaurant: Restaurant)
    }

    // ViewHolderItemクラスはRecyclerView.ViewHolderを継承しています。
    // このクラスはリストの各項目のビューを保持し、再利用を効率的に行います。
    inner class ViewHolderItem(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val ivStorHolder: ImageView = itemView.findViewById(R.id.ivStor) // 画像表示用のImageView
        val tvStorNameHolder: TextView = itemView.findViewById(R.id.tvStorName) // 店名表示用のTextView
        val tvAccessHolder: TextView = itemView.findViewById(R.id.tvAccess) // アクセス情報表示用のTextView

        init {
            // アイテムビューがクリックされたときのリスナー設定
            itemView.setOnClickListener {
                val position = adapterPosition // クリックされた位置を取得
                if (position != RecyclerView.NO_POSITION) {
                    listener.onRestaurantClick(restaurantList[position]) // リスナーを通じてクリックイベントを通知
                }
            }
        }
    }

    // onCreateViewHolderはRecyclerViewのアイテムビューを生成するメソッド
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolderItem {
        val itemXml = LayoutInflater.from(parent.context).inflate(R.layout.list_layout, parent, false)
        return ViewHolderItem(itemXml)
    }

    // onBindViewHolderはアイテムビューにデータをバインドするメソッド
    override fun onBindViewHolder(holder: ViewHolderItem, position: Int) {
        val currentItem = restaurantList[position] // 現在のアイテムを取得
        holder.tvStorNameHolder.text = currentItem.name // 店名をセット
        holder.tvAccessHolder.text = currentItem.access // アクセス情報をセット
        Picasso.get().load(currentItem.logo_image).into(holder.ivStorHolder) // Picassoライブラリを用いて画像を非同期で読み込み、表示
    }

    // getItemCountはリストのアイテム数を返すメソッド
    override fun getItemCount(): Int = restaurantList.size

    // updateDataは新しいデータでリストを更新するメソッド
    fun updateData(newData: List<Restaurant>) {
        restaurantList.clear() // 現在のリストをクリア
        restaurantList.addAll(newData) // 新しいデータを追加
        notifyDataSetChanged() // データが更新されたことをRecyclerViewに通知
    }
}
