package com.example.restaurantsearcherapp

data class RestaurantResponse(
    val results: Results
)

data class Results(
    val shop: List<Restaurant>,
    val results_available: Int
)

data class Restaurant(
    val name: String,
    val logo_image: String,
    val address: String,
    val station_name: String?,
    val average: String?,
    val access: String?,
    val open: String?,
    val close: String?,
    val party_capacity: String?,
    val wifi: String?,
    val wedding: String?,
    val course: String?,
    val free_drink: String?,
    val free_food: String?,
    val private_room: String?,
    val horigotatsu: String?,
    val tatami: String?,
    val card: String?,
    val non_smoking: String?,
    val charter: String?,
    val ktai: String?,
    val parking: String?,
    val barrier_free: String?,
    val other_memo: String?,
    val sommelier: String?,
    val open_air: String?,
    val show: String?,
    val equipment: String?,
    val karaoke: String?,
    val band: String?,
    val tv: String?,
    val english: String?,
    val pet: String?,
    val child: String?,
    val lunch: String?,
    val midnight: String?
)



